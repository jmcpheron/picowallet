# Bring-up profile for HS20HS072RX. Copy beside firmware/lcd.py on the Pico.
# Controller revision, colors, orientation and gamma still need a sample test.
WIDTH = 320
HEIGHT = 240
SPI_HZ = 8_000_000
MADCTL = 0x70
INITIAL_BACKLIGHT = 0
KEYS = {"A": 15, "B": 17, "up": 2, "down": 18,
        "left": 16, "right": 20, "press": 3}
